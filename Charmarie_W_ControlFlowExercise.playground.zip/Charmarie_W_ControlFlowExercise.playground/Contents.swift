import UIKit

let maxTime = 180

for timer in 0...maxTime
{
    print("\(timer) seconds")
    if timer == maxTime{
        print("times up")
    }
}
